import mod from "./index.js";

export default mod;
export const FingerprintGenerator = mod.FingerprintGenerator;
export const PRESETS = mod.PRESETS;
